#include <stdio.h>
#include <stdlib.h>
#define PI 3.14

int main(）
{double r,l,s;
scanf("%lf" &r);
l=2*PI*r;
s=r*r*PI;
printf("%.2lf\n%.2lf\n",l,s);
return 0;}
