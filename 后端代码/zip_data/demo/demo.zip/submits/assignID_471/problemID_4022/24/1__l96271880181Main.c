#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
int main()
{
double r;
  scanf("%lf",r);
  double c,s;
  c=2*r*PI;
  s=PI*r*r;
  printf("%.2f\n%.2f",c,s);
  return 0;

}
