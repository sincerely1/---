#include <stdio.h>
#include <stdlib.h>
#include <math,h>
#define PI 3.1415926

int main()
{
   double a,s,c;
   scanf("%lf",&a);
   s=PI*a*a;
   c=2*PI*a;
   printf("s=%lf,c=%lf",s,c);
   return 0;
}

