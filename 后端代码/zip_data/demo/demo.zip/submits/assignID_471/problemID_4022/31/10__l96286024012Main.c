#include <stdio.h>
#include <stdlib.h>

int main()
{
   double r,s,c,PI=3.14;
   scanf("%lf",&r);
   s=PI*r*r;
   c=PI*r*2;
   printf("%.2f\n%.2f",c,s);
   return 0;
}


