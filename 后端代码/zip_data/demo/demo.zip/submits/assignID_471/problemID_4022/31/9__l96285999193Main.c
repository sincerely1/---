#include <stdio.h>
#include <stdlib.h>

int main()
{
   double r,s,c,PI=3.14;
   scanf("%lf",&r);
   s=PI*r*r;
   c=PI*r*2;
   printf("c=%.2f\ns=%.2f",c,s);
   return 0;
}


