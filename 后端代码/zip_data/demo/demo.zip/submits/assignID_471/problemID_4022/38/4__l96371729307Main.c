#include <stdio.h>
int main(){
#define pai 3.14 //定义π
int r;//定义半径
float c,s;//定义双精度浮点数周长c和面积s
scanf("%d",&r);//输入半径并存入r中
s=pai*r*r;
c=2*pai*r;
printf("%.2f\n",c);
printf("%.2f",s);
return 0;
}



