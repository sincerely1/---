#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
int main()
{
    double a,c,s;
    scanf("%lf",&a);
    c=2.0*PI*a;
    s=PI*a*a;
    printf("c=%.2f",c);
    printf("\ns=%.2f",s);
    return 0;
}
