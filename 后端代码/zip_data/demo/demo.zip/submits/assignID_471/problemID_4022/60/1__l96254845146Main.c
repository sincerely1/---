#include <stdio.h>
#include <stdlib.h>
#define pi 3.14
int main ()
{
    double r,c,s;
    scanf("%lf",&r);
    c=2*pi*r;
    s=pi*r*r;
    printf("c=%.2f,s=%.2f",c,s);
    return 0;
}

