#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
const double PI=3.141;

int main()
{
    int x;
    double C,S;
    scanf("%d",&x);
    C=2.0*PI*x;
    S=PI*x*x;
    printf("%lf\n%lf\n",C,S);
    return 0;
}



