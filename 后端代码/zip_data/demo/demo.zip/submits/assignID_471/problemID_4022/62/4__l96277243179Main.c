#include <stdio.h>
#define PI 3.14
int main(void)
{
  int r=0;
  double S,C;
  scanf("%d",&r);
  S=PI*r*r;
  C=2*PI*r;
  printf("面积S=%.2f\n周长C=%.2f",S,C);
  return 0;
}


