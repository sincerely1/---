#include<stdio.h>
#define pi 3.14
main()
{
float c,s,r;
scanf("%f",&r);
c=(int)(200*pi*r)/100.0;
s=(int)(100*pi*r*r)/100.0;
printf("%.2f\n%.2f\n",c,s);}

