#include <stdio.h>
#include <math.h>
#define PI   3.1415926
int main()
{
  double r,s;
  scanf("%lf",&r);
  s=PI*r*r;
  printf("s=%,2f",s);
  return 0;
}

