#include <stdio.h>
#include <math.h>
#define PI   3.1415926
int main()
{
  double r,s,c;
  scanf("%lf",&r);
  c=2*PI*r;
  s=PI*r*r;
  printf("\nc=%.2f\ns=%.2f",c,s);
  return 0;
}



