#include<stdio.h>
#define M_PI
int main()
{
  double r,l,s;
  scanf("%1f",&r);
  l=2*r*M_PI;
  s=r*r*M_PI;
  printf("%.2f",l);	
  printf("%.2f",s);
  return 0;
}




