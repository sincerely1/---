#define pi 3.14
int main()
{
    double r,s,d;
    scanf("%lf",&r);
    s=r*r*(pi);
    d=2*pi*r;
    printf("s=%0.2f\nd=%0.2f",s,d);
    return 0;
}

