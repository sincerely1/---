int main()
  
{
    double r,s,d,x;
    scanf("%lf",&r);
  	x=3.14
    s=r*r*x;
    d=2*x*r;
    printf("%0.2f\n%0.2f",s,d);
    return 0;
}







