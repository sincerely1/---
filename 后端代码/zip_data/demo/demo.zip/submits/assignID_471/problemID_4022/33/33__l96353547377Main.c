#include <stdio.h>
#include <stdlib.h>
#define pi 3.1416
int main()
{
    double r,s,L;
    scanf("%lf",&r);
    L=pi*r*2;
    s=pi*r*r;
    printf("%100.2lf\n%100.2lf",L,s);
    return 0;
}

