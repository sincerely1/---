#include <stdio.h>
#include <stdlib.h>
#define pi 3.1415926
int main()
{
    double r,s,l;
    scanf("%lf",&r);
    l=pi*r*2;
    s=pi*r*r;
    printf("%.2lf\n%.2lf",l,s);
    return 0;
}

