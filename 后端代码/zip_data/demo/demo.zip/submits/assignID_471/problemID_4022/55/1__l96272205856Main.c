#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14
int main()
{
    double radius,c,s;	/*radius：半径   c：周长  s：面积*/   
	scanf("%lf",radius);
	c=2*PI*radius;
	s=PI*radius*radius;
	printf("%lf\n%lf",c,s); 
   	return 0;
} 
