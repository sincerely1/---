#include <stdio.h>
int main()
{
  float r,p=3.14;
  double c,s;
  scanf("%f",&r);
  c=2*p*r;
  printf("s=%0.2f\n",c);
  s=p*r*r;
  printf("v=%0.2f",s);
  
}

