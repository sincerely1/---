#include <stdio.h>
main()
{
  float r,p=3.14;
  double s,v;
  printf("输入半径r:");
  scanf("%f",&r);
  s=4*p*r*r;
  printf("s=%0.2f\n",s);
  v=4*p*r*r*r/3.0;
  printf("v=%0.2f",v);
  
}
