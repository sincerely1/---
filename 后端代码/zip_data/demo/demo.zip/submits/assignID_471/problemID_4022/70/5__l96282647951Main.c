#include<stdio.h>
#include<stdlib.h>
#define PI 3.1415926
int main()
{
    double r,s,c;
    scanf("%lf",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("%.2f\n%.2f",c,s);
    return 0;

}



