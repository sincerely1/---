#include <math.h>
difine pi=3.1415926;
double a,s,c,pi;
scanf("%lf",&a);
c=pi*2*a;
s=pi*a*a;
printf("%.2lf",s);
printf("%.2lf",c);
return 0;



  
