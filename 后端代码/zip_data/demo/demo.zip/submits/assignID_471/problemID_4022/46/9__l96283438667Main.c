#define PI 3.14
int main()
{
  double r,d,s;
  scanf("%lf",&r);
  d=2.0*PI*r;
  s=PI*r*r;
  printf("%0.2f %0.2f",d,s);
  return 0;
}
  
  









