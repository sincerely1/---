#define pi 3.14
int main ()
{double a,b,c;
 scanf("%lf",&a);
 b=2.0*pi*a;
 c=pi*a*a;
 printf("%.2f",b);
 printf("\n%.2f",c);
 return 0;
 }

