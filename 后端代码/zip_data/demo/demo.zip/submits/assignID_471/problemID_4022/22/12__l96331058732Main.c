#include <stdio.h>
#define PI 3.14
int main(void)
{
  int r=0;
  double S,C;
  scanf("%d",&r);
  S=PI*r*r;
  C=2*PI*r;
  printf("%.2f\n%.2f",C,S);
  return 0;
}















