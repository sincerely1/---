#include <stdio.h>
#include <stdlib.h>

#define pai 3.14

int main()
{double r,l,s;
    scanf("%lf",&r);
    l=2*pai*r;
    s=pai*r*r;
    printf("%0.2f\n%0.2d",l,s);
    return 0;
}

