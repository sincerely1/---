#include <stdio,h>
#define PAI 3.1415926
int main()
{
  double r,l,s;
  scanf("%lf",&r);
  printf("输入圆半径");
  l=2*PAI *r;
  s=PAI*r*r;
  printf("%f",l);
  printf("%f",s);
  return 0;
}
  

