#include <stdio.h>
#define PI 3.14
int main()
{
    double r,s,c;//r为圆的半径，s为圆的面积，c为圆的周长
    scanf("%lf",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("\n%.2lf,\n%.2lf",cs);
    return 0;
}

