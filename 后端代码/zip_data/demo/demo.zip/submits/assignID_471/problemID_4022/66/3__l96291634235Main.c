#include<stdio.h>
#define PI 3.14
main()
{double c,s,r;
 scanf("%lf",&r);
 c=2*PI*r;
 s=PI*r*r;
   printf("c=%lf,s=%lf",c,s);
 return 0;
}
