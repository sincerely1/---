#include <stdio.h>
#include <stdlib.h>
#define pi 3.1415926
int main()
{  double r,c,s;
   scanf("%lf",&r);
   s=pi*r*r;
   c=pi*r*r;
    printf("%.2lf",c);
    printf("\n%.2lf",s);
    return 0;
}



