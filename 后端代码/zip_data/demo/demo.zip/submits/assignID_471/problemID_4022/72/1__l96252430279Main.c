#include <stdio.h>
#include <stdlib.h>
#define pi 3.14
int main()
{  double r,c,s;
   scanf("%lf",&r);
   s=pi*r*r;
   c=pi*r*r;
    printf("%lf",c);
    printf("\n%lf",s);
    return 0;
}

