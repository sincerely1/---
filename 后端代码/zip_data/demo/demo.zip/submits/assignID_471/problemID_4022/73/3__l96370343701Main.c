#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14
int main()
{
    double r,s,c;
    scanf("%lf",&r);
    s=PI*r*r;
    c=PI*2*r;
    printf("%.2lf",c);
    printf("\n%.2lf",s);
    return 0;
}
