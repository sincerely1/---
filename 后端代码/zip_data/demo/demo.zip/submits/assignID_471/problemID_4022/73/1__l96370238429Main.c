int main()
{
    double r,s,c;
    scanf("%lf",&r);
    s=PI*r*r;
    c=PI*2*r;
    printf("%.2lf",c);
    printf("\n%.2lf",s);
    return 0;
}
