#include <stdio.h>
#include <stdlib.h>
#define PI 3.14

int main()
{double r;
 float s,l;
scanf("%lf",&r);
s=PI*r*r;
l=2*PI*r;
printf("%.2f",l);
 printf("\n%.2f",s);
return 0;
}





