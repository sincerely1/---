#define PI 3.1415926
int main()
{
  double x,m,n;
  scanf("%lf",&x);
  m=2*PI*x;
  n=PI*x*x;
  printf("\n%.2f\n%.2f",m,n);
  return 0;
}
  
