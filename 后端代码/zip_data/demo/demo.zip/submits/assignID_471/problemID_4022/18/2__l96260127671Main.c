#include <stdio.h>
#include<math.h>
#define PI 3.14
int main()
{
    double r,s,c;
    scanf("%lf",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("%.2f\n",c);
    printf("%.2f\n",s);
    return 0;
}


