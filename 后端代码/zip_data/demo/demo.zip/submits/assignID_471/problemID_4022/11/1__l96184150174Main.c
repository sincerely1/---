#include<stdio.h>
#define PI 3.14
int main()
{
  double r,C,S;
  scanf("%lf",&r);
  C=2*r*PI;
  S=PI*r*r;
  printf("%.2lf\n%.2lf",C,S);
  return 0;
}
