#include <stdio.h>
#include <stdlib.h>
#define PI 3.1415926

int main()
{

    double r,c,s;
    scanf("%lf",&r);
    c=PI*r*2;
    s=PI*r*r;
    printf("%0.2f\n%0.2f",c,s);

    return 0;
}




