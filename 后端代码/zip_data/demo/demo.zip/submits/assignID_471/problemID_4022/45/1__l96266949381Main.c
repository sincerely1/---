#include<stdio.h>
#define M_PI 3.14
int main()
{
    int a,b;
    printf("请输入圆的半径\n");

	scanf("%d",&a);
	b=a*a;
    float area;
	area =M_PI*b;

	printf("面积为：%.2f\n",area);
	float c;
	c=M_PI*2*a;
	printf("周长为:%.2f\n",c);

	return 0;
}

