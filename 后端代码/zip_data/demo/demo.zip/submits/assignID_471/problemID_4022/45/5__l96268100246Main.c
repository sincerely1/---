#include <stdio.h>
#include <stdlib.h>
#define M_PI 3.14

int main()
{
    int a,b;
    printf("请输入圆的半径\n");

	scanf("%d",&a);
	b=a*a;
    float c;
	c=M_PI*a*2;

	printf("%.2f\n",c);
	float area;
	b=a*a;
	area=M_PI*b;
	printf("%.2f\n",area);

	return 0;
}
