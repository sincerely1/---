#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
int main()
{

    float r,c,s;
    scanf("%f",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("%10.2f\n%10.2f\n",c,s);
    return 0;
}


