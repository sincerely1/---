#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
void main()
{

    float r,c,s;
    scanf("%f",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("c=%10.2f\ns=%10.2f\n",c,s);
    return 0;
}

