#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
int main()
{
    double a,s,l;
    scanf("%lf",&a);
    l=2*PI*a;


    s=PI*a*a;
    printf("%lf\n%lf",l,s);
    return 0;
}
