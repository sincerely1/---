#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define M_PI 3.14
int main()
{  double r,c,s;
   scanf("%lf",&r);
   s=M_PI*r*r;
   c=M_PI*r*2;
    printf("%.2f\n",c);
    printf("%.2f\n",s);
    return 0;

}





