#include <stdio.h>
#include <stdlib.h>
#define pi 3.1415926
int main()
{  double r,c,s;
   scanf("%lf",&r);
   s=pi*r*r;
   c=pi*r*r;
    printf("%.2f",c);
    printf("\n%.2f",s);
    return 0;
}




