#include <stdio.h>
#include <stdlib.h>
#define pi 3.1415926
int main()
{  double r,c,s;
   scanf("%lf",&r);
   s=M_PI*r*r;
   c=M_PI*r*r;
    printf("%.2f\n",c);
    printf("%.2f",s);
    return 0;
}





