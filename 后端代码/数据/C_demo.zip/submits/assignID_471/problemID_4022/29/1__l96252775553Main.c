int main()
{
    double c,s,r,PI;
    PI=3.14;
    scanf("%lf",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("%lf",c);
    printf("\n%lf",s);
    return 0;
}
