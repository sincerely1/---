int main()
{
    double c,s,r,PI;
    PI=3.14;
    scanf("%lf",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("%.2lf",c);
    printf("\n%.2lf",s);
    return 0;
}


