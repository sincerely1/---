int main()
{
    float r,l,s;
    const float PI=3.14;
    scanf("%f",&r);
    l=2*PI*r;
    s=PI*r*r;
    printf("%3.2f\n%3.2f",l,s);
    return 0;
}

