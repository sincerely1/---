#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
int main()
{double r,s,c;
 scanf("%lf",&r);
 s=PI*r*r;
 c=2*PI*r;
 printf("%.2f\n%.2f\n",c,s);
 return 0;
}
   



