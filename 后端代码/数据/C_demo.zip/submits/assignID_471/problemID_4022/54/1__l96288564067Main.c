#include <stdio.h>
#include <stdlib.h>
#define PI 3.14

int main()
{
    double r,l,s;
    scanf("%lf",&r);
    l=2*r*PI;
    s=r*r*PI;
    printf("%4.2lf,%4.2lf\n",l,s);
    return 0;
}

