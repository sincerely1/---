#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
int main()
{
  double a,s,c;
  scanf("%lf",&a);
  s=a*a*PI;
  c=a*PI;
  c=2*c;
  printf("%.2lf\n%.2lf",c,s);
  return 0;
}

