#include <stdio.h>
#include <stdlib.h>
#define pi 3.14
int main()  
{
    double r,s,;
    scanf("%lf",&r);
    s=r*r*pi;
    d=2*pi*r;
    printf("%0.2f\n%0.2f",d,s);
    return 0;
}












