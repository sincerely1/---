int main()
  #define pi 3.14
{
    double r,s,d;
    scanf("%d",&r);
    s=r*r*(pi);
    d=2*pi*r;
    printf("%0.2f\n%0.2f",s,d);
    return 0;
}






