#include <stdio.h>
#include <stdlib.h>
#define Pi 3.14
int main()
{
    double r;
    double c,s;
    scanf("%lf",&r);
    c=2*Pi*r;
    s=Pi*r*r;
    printf("c=%.2f,s=%.2f",c,s);
    return 0;
}








