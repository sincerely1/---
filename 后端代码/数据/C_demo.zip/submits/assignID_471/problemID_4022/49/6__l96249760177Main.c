#include <stdio.h>
#define PAI 3.14
int main()
{
  double r,l,s;
  scanf("%lf",&r);
  printf("输入圆半径");
  l=2*PAI*r;
  s=PAI*r*r;
  printf("%0.2f",l);
  printf("\n%0.2f",s);
  return 0;
}
  









