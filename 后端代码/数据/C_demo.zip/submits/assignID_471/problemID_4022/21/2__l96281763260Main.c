int main()
{  int a,b,c,avge;
   scanf("%d%d%d",&a,&b,&c);
   avge=(a+b+c)/3;
   printf("%d",avge);
   return 0;
}

