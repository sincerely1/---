#include<studio.h>
#include<stdlib.h>
#define PI 3.1415926
 int main()
 {
   double r,c,s;
   scanf("%1f",&f);
   c=PI*2*r
   s=PI*r*r
   printf("%.21f\n%.21F\n",c,s);
   return 0;
 }


