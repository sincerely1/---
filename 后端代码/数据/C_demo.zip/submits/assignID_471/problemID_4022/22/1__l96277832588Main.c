#define PI 3.14
#include <stdio.h>
int main()
{
  double r,c,s;
  scanf("%lf",&r);
  c=2*r*PI;
  s=PI*r*r;
  printf("%.2lf\n%.2lf",c,s);
  return 0;
