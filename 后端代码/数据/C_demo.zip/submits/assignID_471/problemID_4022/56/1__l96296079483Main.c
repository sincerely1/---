#include<stdio.h>
#define PI 3.14
int main()
{
  double r,c,S;
  scanf("%lf",&r);
  c=2*PI*r;
  S=PI*r*r;
  printf("%.2f\n%.2f\n",c,S);
  return 0;
}
