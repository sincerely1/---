#define PI 3.1415926
int main()
{
    double r,s,l;
    scanf("%lf",&r);
    s=PI*r*r;
    l=2*PI*r;
    printf("%.2f\n%.2f",l,s);
    return 0;
}

