#include<stdio.h>
#include<stdlib.h>
#define PI 3.14
int main()
{
    double r,s,c;
    scanf("%lf",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("%.2lf\n%.2lf",c,s);
    return 0;
}



