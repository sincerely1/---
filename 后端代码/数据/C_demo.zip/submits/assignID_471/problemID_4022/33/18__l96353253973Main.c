#include <stdio.h>
#include <stdlib.h>
#define pi3.1415926
int main()
{
    double r,s,l;
    scanf("%lf",&r);
    l=pi*r*2;
    s=pi*r*r;
    printf("%lf\n%lf",l,s);
    return 0;
}

