#include<stdio.h>
#include<stdlib.h>
#define Pi 3.14
int main()
{
    double r=3;
    double s=0;
    double c=0;
    scanf("%lf",&r);
    c=2*Pi*r;
    s=Pi*r*r;
    printf("%.2lf\n%.2lf",c,s);
    return 0;
}

