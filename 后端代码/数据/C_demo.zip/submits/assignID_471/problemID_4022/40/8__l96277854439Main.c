#include <stdio.h>
#include <stdlib.h>
#define PI  3.1415926
int main()
{double r,s,c;
scanf("%lf",&r);
 c=PI*r*r;
 s=2*PI*r;
 printf("%.2f%",s) printf("\n%.2f%",c)；
    return 0;
}



