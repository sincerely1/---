#include <stdio.h>
#include <stdlib.h>
#include<math.h>
#define PI 3.14 
int main()
{
    double r,s,c;
    scanf("%lf",&r);
    c=2*PI*r;
    s=PI*r*r;
    printf("%.2lf\n",c);
    printf("%.2lf",s);
    return 0;
}


