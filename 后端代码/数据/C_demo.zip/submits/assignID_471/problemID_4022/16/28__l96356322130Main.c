#include <stdio.h>
#include <math.h>
#define PI 3.14

int main()
{float r,l,s;
scanf("%f",&r);
l=(int)(200*PI*r)/100.0;
s=(int)(100*r*r*PI)/100.0;
printf("%.2f\n%.2f\n",l,s);
return 0;}

		 
		 


