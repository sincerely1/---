#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14

int main()
{
    double r,s,c;
    printf("请输入半径\n");
    scanf("%lf",&r);
    s=PI*r*r;
    c=2*PI*r;
    printf("%.2lf\n%.2lf",s,c);
    return 0;
}

