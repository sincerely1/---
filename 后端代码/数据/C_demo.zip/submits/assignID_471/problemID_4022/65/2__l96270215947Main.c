#include<stdio.h>
#include<math.h>
#define M_PI
int main()
{
  double r,l,s;
  scanf(%f%f%f,&l,&s);
  l=2*r*M_PI;
  s=r*r*M_PI;
  printf(%f%f,l,s);	
  return 0;
}


