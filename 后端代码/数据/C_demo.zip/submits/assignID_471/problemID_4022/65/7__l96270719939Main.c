#include<stdio.h>
#define M_PI 3.14
int main()
{
  double r,c,s;
  scanf("%1f",&r);
  c=2*r*M_PI;
  s=r*r*M_PI;
  printf("%.2f",c);	
  printf("\n%.2f",s);
  return 0;
}







