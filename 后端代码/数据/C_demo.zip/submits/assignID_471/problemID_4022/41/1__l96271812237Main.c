#include<stdio.h>
#define PI 3.14
int main()
{
	float r,s,l;
	scanf("%f",&r);
	s=PI*r*r;
	l=PI*r*2;
	printf("%.2f\n%.2f",l,s);
	
	
	return 0;
}
