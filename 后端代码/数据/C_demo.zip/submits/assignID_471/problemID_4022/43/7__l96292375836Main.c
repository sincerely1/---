#include <math.h>
#define pi 3.14
int main()
{
double a,s,c;
scanf("%lf",&a);
c=pi*2*a;
s=pi*a*a;
printf("%.2lf",s);
printf("%.2lf",c);
return 0;
}


  
