#include <stdio.h>
#include <stdlib.h>
#define PI 3.14
int main()
{
    double r,l,s;
    scanf("%lf",&r);
    l=2*r*PI;
    s=PI*r*r;
    printf("%.2f\n%.2f",l,s);
    return 0;
}
