#include <stdio.h>
#include <math.h>
#define PI 3.14
int main(void)
{
  double r,a,s;
  scanf("%lf",&r);
  a=2*PI*r;
  s=PI*r*r;
  printf("%.2lf\n%.2lf",a,s);
  return 0;
}
