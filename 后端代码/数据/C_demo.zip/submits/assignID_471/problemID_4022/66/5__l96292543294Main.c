#include<stdio.h>
#define PI 3.14
int main()
{
  double c,s,r;
 scanf("%lf",&r);
 c=2*PI*r;
 s=PI*r*r;
   printf("%.2f\n%.2f",c,s);
 return 0;
}
