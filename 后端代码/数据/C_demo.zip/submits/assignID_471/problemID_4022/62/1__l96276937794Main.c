#include <stdio.h>
#define PI 3.1415926
int main(void)
{
  double r,S,C;
  scanf("%lf",&r);
  S=PI*r*r;
  C=2*PI*r;
  printf("周长C=%.2f\n面积S=%.2f",S,C);
  return 0;
}
