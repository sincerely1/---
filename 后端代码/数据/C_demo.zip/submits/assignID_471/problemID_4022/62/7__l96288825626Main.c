#include <stdio.h>
#define PI 3.14
int main()
{
  double r,c,s;
  scanf("%lf",&r);
  c=PI*2*r;
  s=PI*r*r;
  printf("c=%.2f\ns=%.2f",c,s);
  return 0;
}
