#include<stdio.h>
#define PI 3.14
int main()
{
  double r,d,s;
  scanf("%lf",&r);
  d=2.0*PI*r;
  s=PI*r*r;
  printf("%.2f\n%.2f/n",d,s);
  return 0;
}
  
  













