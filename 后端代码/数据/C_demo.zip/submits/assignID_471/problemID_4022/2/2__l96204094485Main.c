#include<stdio.h>
#include<stdlib.h>
#define PI        3.14
int main ()
{
  double r=0;
  double c=0,s=0;
  scanf("%lf",&r);
  c=PI*r*2;
  s=PI*r*r;
  printf("%.2lf\n%.2lf",c,s);
  return 0;
}  
