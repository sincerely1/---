#include<stdio.h>
#defind PI 3.14



double area(double r)
{
  return PI*r*r;
}
double girth(double r)
{
  return 2*PI*r;
}

int main()
{
  double r,c,s;
  scanf("%f",&r);
  s=area(r);
  c=girth(r);
  printf("c=%.2f,\ns=%.2f",c,s);
  return 0;
}
