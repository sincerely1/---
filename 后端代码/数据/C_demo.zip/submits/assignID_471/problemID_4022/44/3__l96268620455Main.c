#include<stdio.h>


int main()
{
  double r,c,s,p;
  p=3.14;
  scanf("%f",&r);
  s=p*r*r;
  c=2*p*r;
  printf("c=%.2f,\ns=%.2f",c,s);
  return 0;
}


