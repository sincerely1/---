#include<stdio.h>


int main()
{
  double r,c,s,p=3.14;
  
  scanf("%lf",&r);
  s=p*r*r;
  c=2*p*r;
  printf("%.2f,\n%.2f",c,s);
  return 0;
}




