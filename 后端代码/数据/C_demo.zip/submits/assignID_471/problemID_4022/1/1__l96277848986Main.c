
int main ()
{double a,b,c;
 scanf("%lf"，&a);
 b=2*3.14*a;
 c=3.14*a*a;
 printf("%f",b);
 printf("\n%f",c);
 return 0
 }
