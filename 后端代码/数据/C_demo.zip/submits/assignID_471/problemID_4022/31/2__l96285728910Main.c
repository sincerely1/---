#include <stdio.h>
#include <stdlib.h>

int main()
{
   double r,s,PI=3.14;
   scanf("%lf",&r);
   s=PI*r*r;
   printf("s=%.2f",s);
   return 0;
}
