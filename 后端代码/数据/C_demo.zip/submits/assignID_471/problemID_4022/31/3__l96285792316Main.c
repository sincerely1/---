#include <stdio.h>
#include <stdlib.h>

int main()
{
   double r,s,c,PI=3.14;
   scanf("%lf",&r);
   s=PI*r*r;
   c=PI*r*2;
   printf("s=%.2f c=%.2f",s,c);
   return 0;
}
